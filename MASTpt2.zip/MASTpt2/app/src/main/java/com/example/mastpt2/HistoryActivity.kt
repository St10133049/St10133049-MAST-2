import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val historyTextView: TextView = findViewById(R.id.historyTextView)
        // ...

        private fun getLastThreeBooks(): List<Book> {
            return bookList.takeLast(3)
        }

// ...

        val lastThreeBooks = getLastThreeBooks()
        historyTextView.text = lastThreeBooks.joinToString("\n") { "${it.title} by ${it.author}" }

        return emptyList()
    }
}
