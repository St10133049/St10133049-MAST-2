import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class GenreActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genre)

        val genreStatsTextView: TextView = findViewById(R.id.genreStatsTextView)

        // ...

        private fun getGenreStatistics(): List<Pair<String, Int>> {
            val genreMap = mutableMapOf<String, Int>()

            for (book in bookList) {
                val genre = book.genre
                genreMap[genre] = genreMap.getOrDefault(genre, 0) + 1
            }

            return genreMap.toList()
        }

    // ...

        val genreStats = getGenreStatistics()
        genreStatsTextView.text = genreStats.joinToString("\n") { "Genre: ${it.first}, Total Books: ${it.second}" }
    }


}
