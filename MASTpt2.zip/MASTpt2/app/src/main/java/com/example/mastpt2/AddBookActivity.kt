import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity

class AddBookActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_book)

        val titleEditText: EditText = findViewById(R.id.titleEditText)
        val authorEditText: EditText = findViewById(R.id.authorEditText)
        val genreSpinner: Spinner = findViewById(R.id.genreSpinner)
        val pagesEditText: EditText = findViewById(R.id.pagesEditText)
        val addButton: Button = findViewById(R.id.addButton)

        // Set up genre spinner with predefined genres
        val genres = arrayOf("Mystery", "Science Fiction", "Fantasy", "Romance", "Thriller")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genres)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genreSpinner.adapter = adapter

        // Add button click listener to save book
        addButton.setOnClickListener {
            val title = titleEditText.text.toString()
            val author = authorEditText.text.toString()
            val genre = genreSpinner.selectedItem.toString()
            val pages = pagesEditText.text.toString().toIntOrNull()

            if (title.isNotEmpty() && author.isNotEmpty() && pages != null) {
                // ...

                private fun saveBook(title: String, author: String, genre: String, pages: Int) {
                    val newBook = Book(title, author, genre, pages)
                    bookList.add(newBook)
                    // save the book list to a database.
                }

// ...
            }
            finish()
        }
    }
}
