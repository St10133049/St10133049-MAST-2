import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var lastBookDetails: TextView
    private lateinit var totalPages: TextView
    private lateinit var averagePages: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        lastBookDetails = findViewById(R.id.lastBookDetails)
        totalPages = findViewById(R.id.totalPages)
        averagePages = findViewById(R.id.averagePages)

        // Retrieve and display last book details
        val lastBook = getLastBook()
        if (lastBook != null) {
            lastBookDetails.text = "Last Book Read:\n${lastBook.title} by ${lastBook.author}\nGenre: ${lastBook.genre}\nPages: ${lastBook.pages}"
        }

        // Retrieve and display total pages and average pages
        val totalReadPages = getTotalPagesRead()
        val averageReadPages = getAveragePagesRead()
        totalPages.text = "Total Pages Read: $totalReadPages"
        averagePages.text = "Average Pages: $averageReadPages"

        // Set click listeners for buttons
        findViewById<TextView>(R.id.addBookButton).setOnClickListener {
            startActivity(Intent(this, AddBookActivity::class.java))
        }
        findViewById<TextView>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<TextView>(R.id.genreButton).setOnClickListener {
            startActivity(Intent(this, GenreActivity::class.java))
        }
    }

    // ...

    private lateinit var bookList: MutableList<Book>

    // ...

    private fun getLastBook(): Book? {
        return bookList.lastOrNull()
    }

    private fun getTotalPagesRead(): Int {
        return bookList.sumBy { it.pages }
    }

    private fun getAveragePagesRead(): Float {
        return if (bookList.isNotEmpty()) {
            bookList.averageBy { it.pages }.toFloat()
        } else {
            0f
        }
    }

// ...

}
}
